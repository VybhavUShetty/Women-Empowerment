package com.lti.WE.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.WE.entity.Contact_Details;
import com.lti.WE.service.Contact_DetailsService;

@Controller
public class ContactRegisterController {
	private Contact_DetailsService cregisterService;

	public ContactRegisterController() {

	}

	@Autowired
	public ContactRegisterController(Contact_DetailsService cregisterService) {
		this.cregisterService = cregisterService;
	}


	@RequestMapping(value = {"/Contact_Details" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Contact_Details");
		return mv;
	}

	// Get All Users
/*	@RequestMapping(value = "/allUsers", method = RequestMethod.POST)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<Author> userList = userService.getAllUsers();
		mv.addObject("userList", userList);
		mv.setViewName("allUsers");
		return mv;
	}*/

	@RequestMapping(value = "/addContact_Details", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("Contact_Details");
		mv.addObject("headerMessage", "Add Registration Details");
		mv.addObject("cregister", new Contact_Details());
		return mv;
	}

	@RequestMapping(value = "/addContact_Details", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute Contact_Details cregister, BindingResult result) {
		ModelAndView mv = new ModelAndView("Training_Details");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = cregisterService.saveUser(cregister);
		if (isAdded) {
			mv.addObject("message", "New user successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;
	
	}
}
