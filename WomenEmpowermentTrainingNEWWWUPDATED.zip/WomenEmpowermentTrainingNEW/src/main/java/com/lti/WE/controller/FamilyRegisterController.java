package com.lti.WE.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.WE.entity.Family_Details;
import com.lti.WE.service.Family_DetailsService;
@Controller
public class FamilyRegisterController {
	private Family_DetailsService fregisterService;

	public FamilyRegisterController() {

	}

	@Autowired
	public FamilyRegisterController(Family_DetailsService fregisterService) {
		this.fregisterService = fregisterService;
	}


	@RequestMapping(value = {"/Family_Details" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Family_Details");
		return mv;
	}

	// Get All Users
/*	@RequestMapping(value = "/allUsers", method = RequestMethod.POST)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<Author> userList = userService.getAllUsers();
		mv.addObject("userList", userList);
		mv.setViewName("allUsers");
		return mv;
	}*/

	@RequestMapping(value = "/addFamily_Details", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("Family_Details");
		mv.addObject("headerMessage", "Add Registration Details");
		mv.addObject("fregister", new Family_Details());
		return mv;
	}

	@RequestMapping(value = "/addFamily_Details", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute Family_Details fregister, BindingResult result) {
		ModelAndView mv = new ModelAndView("/Contact_Details");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = fregisterService.saveUser(fregister);
		if (isAdded) {
			mv.addObject("message", "New user successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;
	
	}
}
