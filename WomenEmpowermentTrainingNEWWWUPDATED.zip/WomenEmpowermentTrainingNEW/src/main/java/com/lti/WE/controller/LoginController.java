package com.lti.WE.controller;


import java.util.Map;

import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lti.WE.entity.Register;
import com.lti.WE.service.LoginService;


@Controller
public class LoginController {
	@Resource
	private LoginService loginservice;

	static String name;	 
	 @RequestMapping(path = "/addlogin")
		public String registration(@RequestParam("user_name") String user_name, @RequestParam("password") String password,  Map model, ModelMap uname)  {
		 Register register = loginservice.isValidUser(user_name, password);
			model.put("register", register);
			 name=register.getUser_name();
			 uname.addAttribute("name",name);
			//System.out.println(student);
			return "STEP_Page";		
			
		}
	 
	 @RequestMapping(value="/AdminLoginCheck",method=RequestMethod.GET)
		public ModelAndView steploginUser2(){
			ModelAndView mv = new ModelAndView("AdminLoginCheck");
			mv.setViewName("AdminLoginCheck");
			return mv;
		}
	 
	 @RequestMapping(value="/AdminLogin",method=RequestMethod.GET)
		public ModelAndView steploginUser1(){
			ModelAndView mv = new ModelAndView("AdminLogin");
			mv.setViewName("AdminLogin");
			return mv;
		}
	 
	 @RequestMapping(value="/Adminhome",method=RequestMethod.GET)
		public ModelAndView steploginUser4(){
			ModelAndView mv = new ModelAndView("Adminhome");
			mv.setViewName("Adminhome");
			return mv;
		}
}
