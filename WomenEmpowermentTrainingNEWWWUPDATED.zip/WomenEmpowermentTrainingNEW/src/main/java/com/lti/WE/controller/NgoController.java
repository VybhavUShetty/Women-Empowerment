package com.lti.WE.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.WE.entity.NGO_Register;
import com.lti.WE.service.NgoService;

@Controller
public class NgoController{
	// Constructor based Dependency Injection
	private NgoService ngoService;

	public NgoController() {

	}

	@Autowired
	public NgoController(NgoService ngoService) {
		this.ngoService = ngoService;
	}


	@RequestMapping(value = { "/Ngo_Register" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Ngo_Register");
		return mv;
	}

	// Get All Users
/*	@RequestMapping(value = "/allUsers", method = RequestMethod.POST)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<Author> userList = userService.getAllUsers();
		mv.addObject("userList", userList);
		mv.setViewName("allUsers");
		return mv;
	}*/

	@RequestMapping(value = "/addNgo_Register", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("Ngo_Register");
		mv.addObject("headerMessage", "Add Registration Details");
		mv.addObject("ngoregister", new  NGO_Register());
		return mv;
	}

	@RequestMapping(value = "/addNgo_Register", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute NGO_Register ngoregister, BindingResult result) {
		ModelAndView mv = new ModelAndView("/NGO_Page");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = ngoService.saveNgoUser(ngoregister);
		if (isAdded) {
			mv.addObject("message", "New user successfully added");
		} else {
			return new ModelAndView("error");
		}
	
		return mv;
	}
}
