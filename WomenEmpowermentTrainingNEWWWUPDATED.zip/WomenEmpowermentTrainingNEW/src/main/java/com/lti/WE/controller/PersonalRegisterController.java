package com.lti.WE.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.WE.entity.Personal_Details;
import com.lti.WE.service.Personal_DetailsService;

@Controller
public class PersonalRegisterController {
	// Constructor based Dependency Injection
	private Personal_DetailsService pregisterService;

	public PersonalRegisterController() {

	}

	@Autowired
	public PersonalRegisterController(Personal_DetailsService pregisterService) {
		this.pregisterService = pregisterService;
	}


	@RequestMapping(value = { "/addPersonal_Details" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Personal_Details");
		return mv;
	}

	// DIsplay list
	@RequestMapping(value = "/allPdetails", method = RequestMethod.POST)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Registered Users");
		ModelAndView mv = new ModelAndView();
		List<Personal_Details> userList = pregisterService.getAllUsers();
		mv.addObject("userList", userList);
		mv.setViewName("allPdetails");
		return mv;
	}
	

	@RequestMapping(value = "/Personal_Details", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("Personal_Details");
		mv.addObject("headerMessage", "Add Registration Details");
		mv.addObject("pregister", new Personal_Details());
		return mv;
	}

	@RequestMapping(value = "/Personal_Details", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute Personal_Details pregister, BindingResult result) {
		ModelAndView mv = new ModelAndView("/Family_Details");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = pregisterService.saveUser(pregister);
		if (isAdded) {
			mv.addObject("message", "New user successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;

}
	//delete user
@RequestMapping(value = "/deleteUser/{reg_id}", method = RequestMethod.GET)
	public ModelAndView deleteUserById(@PathVariable int reg_id) {
		boolean isDeleted = pregisterService.deleteUserById(reg_id);
		System.out.println("User deletion respone: " + isDeleted);
		ModelAndView mv = new ModelAndView("redirect: /Adminhome");
		return mv;

	}
	

}