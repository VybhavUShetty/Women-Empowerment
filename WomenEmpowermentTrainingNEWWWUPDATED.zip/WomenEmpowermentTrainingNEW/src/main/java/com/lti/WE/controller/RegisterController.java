package com.lti.WE.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.WE.entity.Register;
import com.lti.WE.service.RegisterService;

@Controller
public class RegisterController {
	// Constructor based Dependency Injection
	private RegisterService registerService;

	public RegisterController() {

	}
	@Autowired
	public RegisterController(RegisterService registerService) {
		this.registerService = registerService;
	}
	@RequestMapping(value = {"/Register" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Register");
		return mv;
	}

	// Get All Users
/*	@RequestMapping(value = "/allUsers", method = RequestMethod.POST)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<Author> userList = userService.getAllUsers();
		mv.addObject("userList", userList);
		mv.setViewName("allUsers");
		return mv;
	}*/

	@RequestMapping(value = "/addRegister", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("Register");
		mv.addObject("headerMessage", "Add Registration Details");
		mv.addObject("register", new Register());
		return mv;
	}

	@RequestMapping(value = "/addRegister", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute Register register, BindingResult result) {
		ModelAndView mv = new ModelAndView("Login");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = registerService.saveUser(register);
		if (isAdded) {
			mv.addObject("message", "New user successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;

}
	
	@RequestMapping(value="/Login",method=RequestMethod.GET)
	public ModelAndView steploginUser(){
		ModelAndView mv = new ModelAndView("Login");
		mv.setViewName("Login");
		return mv;
	}
	
	@RequestMapping(value="/About",method=RequestMethod.GET)
	public ModelAndView steploginUser1(){
		ModelAndView mv = new ModelAndView("About");
		mv.setViewName("About");
		return mv;
	}
	@RequestMapping(value="/LegislationAndPolicy",method=RequestMethod.GET)
	public ModelAndView steploginUser3(){
		ModelAndView mv = new ModelAndView("LegislationAndPolicy");
		mv.setViewName("LegislationAndPolicy");
		return mv;
	}
	
	
}