package com.lti.WE.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.WE.entity.Training_Details;
import com.lti.WE.service.Training_DetailsService;

@Controller
public class TrainingRegisterController {
	// Constructor based Dependency Injection
	private Training_DetailsService tregisterService;

	public TrainingRegisterController() {

	}

	@Autowired
	public TrainingRegisterController(Training_DetailsService tregisterService) {
		this.tregisterService = tregisterService;
	}


	@RequestMapping(value = { "/Training_Details" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Training_Details");
		return mv;
	}

	// Get All Users
/*	@RequestMapping(value = "/allUsers", method = RequestMethod.POST)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<Author> userList = userService.getAllUsers();
		mv.addObject("userList", userList);
		mv.setViewName("allUsers");
		return mv;
	}*/

	@RequestMapping(value = "/addTraining_Details", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("Training_Details");
		mv.addObject("headerMessage", "Add Registration Details");
		mv.addObject("tregister", new Training_Details());
		return mv;
	}

	@RequestMapping(value = "/addTraining_Details", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute Training_Details tregister, BindingResult result) {
		ModelAndView mv = new ModelAndView("/STEP_Page");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = tregisterService.saveUser(tregister);
		if (isAdded) {
			mv.addObject("message", "New user successfully added");
		} else {
			return new ModelAndView("error");
		}
	
		return mv;
	}
		
		@RequestMapping(value="/addNGO_Page",method= RequestMethod.GET)
		public ModelAndView displayngo(){
			ModelAndView mv=new ModelAndView("/NGO_Page");
			return mv;
		}

}
