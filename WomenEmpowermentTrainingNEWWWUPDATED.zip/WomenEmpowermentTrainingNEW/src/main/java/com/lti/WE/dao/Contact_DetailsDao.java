package com.lti.WE.dao;
import com.lti.WE.entity.Contact_Details;
/*
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.lti.WE.entity.Contact_Details;
@Repository
public interface Contact_DetailsDao extends 
CrudRepository<Contact_Details,Long>{

}
*/
public interface Contact_DetailsDao {

	//public List<User> getAllUsers();
	//public User getUserById(Long id);
	public Boolean saveUser(Contact_Details cdetails);
	//public boolean deleteUserById(Long id);
	

}