package com.lti.WE.dao;
import org.springframework.stereotype.Repository;

import com.lti.WE.entity.Contact_Details;
@Repository("Contact_DetailsDao")
public class Contact_DetailsDaoImpl extends AbstractDao<Long, Contact_Details> implements Contact_DetailsDao {

	/*@Override
	public List<User> getAllUsers() {
			@SuppressWarnings("unchecked")
			List<User> il=getEntityManager().createQuery("SELECT u FROM User u ").getResultList();
		return il;
	}

	/*@Override
	public User getUserById(Long id) {
		User ins=(User) getEntityManager()
                .createQuery("SELECT u FROM User u WHERE u.ques_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		return ins;
	}*/

	public Boolean saveUser(Contact_Details cdetails) {
		persist(cdetails);
		return true;
	}

	/*@Override
	public boolean deleteUserById(Long id) {
		// TODO Auto-generated method stub
		User ins=(User) getEntityManager()
                .createQuery("SELECT u FROM User u WHERE u.ques_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		delete(ins);
		return true;
	}
*/
}