package com.lti.WE.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.lti.WE.entity.Contact_Details;
import com.lti.WE.entity.Family_Details;
/*
@Repository
public interface Family_DetailsDao extends 
CrudRepository<Family_Details,Long>{
	
}*/
public interface Family_DetailsDao {

	//public List<User> getAllUsers();
	//public User getUserById(Long id);
	public Boolean saveUser(Family_Details fdetails);
	//public boolean deleteUserById(Long id);
	

}