
package com.lti.WE.dao;
import org.springframework.stereotype.Repository;
import com.lti.WE.entity.Family_Details;
@Repository("Family_DetailsDao")
public class Family_DetailsDaoImpl extends AbstractDao<Long, Family_Details> implements Family_DetailsDao {

	/*@Override
	public List<User> getAllUsers() {
			@SuppressWarnings("unchecked")
			List<User> il=getEntityManager().createQuery("SELECT u FROM User u ").getResultList();
		return il;
	}

	/*@Override
	public User getUserById(Long id) {
		User ins=(User) getEntityManager()
                .createQuery("SELECT u FROM User u WHERE u.ques_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		return ins;
	}*/

	public Boolean saveUser(Family_Details fdetails) {
		persist(fdetails);
		return true;
	}

	/*@Override
	public boolean deleteUserById(Long id) {
		// TODO Auto-generated method stub
		User ins=(User) getEntityManager()
                .createQuery("SELECT u FROM User u WHERE u.ques_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		delete(ins);
		return true;
	}
*/
}