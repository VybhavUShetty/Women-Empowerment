package com.lti.WE.dao;
import com.lti.WE.entity.Register;
public interface LoginDao {

	public Register isValidUser1(String user_name, String password);
}

