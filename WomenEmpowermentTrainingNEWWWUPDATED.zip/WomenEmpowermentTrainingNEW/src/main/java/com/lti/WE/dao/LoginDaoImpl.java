package com.lti.WE.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.WE.entity.Register;
@Repository("LoginDao")
public class LoginDaoImpl extends AbstractDao<Long, Register> implements LoginDao{

	@PersistenceContext
	private EntityManager entityManager;
	@Transactional
       public Register isValidUser1(String user_name, String password) {
		String ql = "select u from Register u where u.user_name = :un and u.password = :pwd";
		Query q = entityManager.createQuery(ql);
		q.setParameter("un", user_name);
		q.setParameter("pwd", password);
		return (Register) q.getSingleResult();
	}
	

}