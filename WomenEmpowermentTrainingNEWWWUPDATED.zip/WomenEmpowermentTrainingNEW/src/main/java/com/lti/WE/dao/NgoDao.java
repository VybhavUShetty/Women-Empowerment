package com.lti.WE.dao;
import com.lti.WE.entity.NGO_Register;

/*@Repository
public interface NgoDao extends 
	CrudRepository<NGO_Register,Long>{

}*/
public interface NgoDao {

	//public List<User> getAllUsers();
	//public User getUserById(Long id);
	public Boolean saveUser(NGO_Register ngoregister);
	//public boolean deleteUserById(Long id);
	

}
