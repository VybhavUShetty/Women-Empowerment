package com.lti.WE.dao;
import org.springframework.stereotype.Repository;
import com.lti.WE.entity.NGO_Register;
@Repository("NgoDao")
public class NgoDaoImpl extends AbstractDao<Long, NGO_Register> implements NgoDao {

	/*@Override
	public List<User> getAllUsers() {
			@SuppressWarnings("unchecked")
			List<User> il=getEntityManager().createQuery("SELECT u FROM User u ").getResultList();
		return il;
	}

	/*@Override
	public User getUserById(Long id) {
		User ins=(User) getEntityManager()
                .createQuery("SELECT u FROM User u WHERE u.ques_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		return ins;
	}*/

	public Boolean saveUser(NGO_Register ngoregister) {
		persist(ngoregister);
		return true;
	}

	/*@Override
	public boolean deleteUserById(Long id) {
		// TODO Auto-generated method stub
		User ins=(User) getEntityManager()
                .createQuery("SELECT u FROM User u WHERE u.ques_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		delete(ins);
		return true;
	}
*/
}