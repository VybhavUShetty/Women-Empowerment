package com.lti.WE.dao;
import java.util.List;

import org.springframework.stereotype.Repository;
import com.lti.WE.entity.Personal_Details;
@Repository("Personal_DetailsDao")
public class Personal_DetailsDaoImpl extends AbstractDao<Long, Personal_Details> implements Personal_DetailsDao {

	
	public List<Personal_Details> getAllUsers() {
			@SuppressWarnings("unchecked")
			List<Personal_Details> il=getEntityManager().createQuery("SELECT u FROM Personal_Details u ").getResultList();
		return il;
	}

	
	public Personal_Details getUserById(int reg_id) {
		Personal_Details ins=(Personal_Details) getEntityManager()
                .createQuery("SELECT u FROM Personal_Details u WHERE u.reg_id LIKE :reg_id")
                .setParameter("reg_id",reg_id)
                .getSingleResult();
		return ins;
	}

	public Boolean saveUser(Personal_Details pdetails) {
		persist(pdetails);
		return true;
	}

	
	public boolean deleteUserById(int reg_id) {
		// TODO Auto-generated method stub
		Personal_Details ins=(Personal_Details) getEntityManager()
                .createQuery("SELECT u FROM Personal_Details u WHERE u.reg_id LIKE :reg_id")
                .setParameter("reg_id",reg_id)
                .getSingleResult();
		delete(ins);
		return true;
	}

}