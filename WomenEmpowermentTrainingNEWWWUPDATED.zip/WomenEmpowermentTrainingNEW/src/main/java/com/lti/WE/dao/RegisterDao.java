package com.lti.WE.dao;
import com.lti.WE.entity.Register;
/*@Repository
public interface RegisterDao extends 
CrudRepository<Register,Long>{
	
}*/

public interface RegisterDao {

	//public List<User> getAllUsers();
	//public User getUserById(Long id);
	public Boolean saveUser(Register register);
	//public boolean deleteUserById(Long id);
	

}
