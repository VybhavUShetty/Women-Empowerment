package com.lti.WE.dao;

import com.lti.WE.entity.Training_Details;
/*@Repository
public interface Training_DetailsDao extends 
CrudRepository<Training_Details,Long>{	
}
*/
public interface Training_DetailsDao {

	//public List<User> getAllUsers();
	//public User getUserById(Long id);
	public Boolean saveUser(Training_Details tdetails);
	//public boolean deleteUserById(Long id);
	

}
