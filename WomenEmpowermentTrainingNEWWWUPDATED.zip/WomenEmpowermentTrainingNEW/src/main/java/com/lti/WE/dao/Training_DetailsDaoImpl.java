package com.lti.WE.dao;
import org.springframework.stereotype.Repository;
import com.lti.WE.entity.Training_Details;
@Repository("Training_DetailsDao")
public class Training_DetailsDaoImpl extends AbstractDao<Long, Training_Details> implements Training_DetailsDao {

	/*@Override
	public List<User> getAllUsers() {
			@SuppressWarnings("unchecked")
			List<User> il=getEntityManager().createQuery("SELECT u FROM User u ").getResultList();
		return il;
	}

	/*@Override
	public User getUserById(Long id) {
		User ins=(User) getEntityManager()
                .createQuery("SELECT u FROM User u WHERE u.ques_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		return ins;
	}*/

	public Boolean saveUser(Training_Details tdetails) {
		persist(tdetails);
		return true;
	}

	/*@Override
	public boolean deleteUserById(Long id) {
		// TODO Auto-generated method stub
		User ins=(User) getEntityManager()
                .createQuery("SELECT u FROM User u WHERE u.ques_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		delete(ins);
		return true;
	}
*/
}