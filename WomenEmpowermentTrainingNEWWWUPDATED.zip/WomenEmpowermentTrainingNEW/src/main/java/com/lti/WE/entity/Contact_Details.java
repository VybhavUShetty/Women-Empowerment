package com.lti.WE.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="contact_details")
public class Contact_Details {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="cid")
	@SequenceGenerator(name="cid",sequenceName="c_no",allocationSize=1)
	private int cid;
	private int phone_no;
	private String email;
	private String city;
	private String state;
	private int pincode;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(int phone_no) {
		this.phone_no = phone_no;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Contact_Details [cid=" + cid + ", phone_no=" + phone_no + ", email=" + email + ", city=" + city
				+ ", state=" + state + ", pincode=" + pincode + "]";
	}

}
