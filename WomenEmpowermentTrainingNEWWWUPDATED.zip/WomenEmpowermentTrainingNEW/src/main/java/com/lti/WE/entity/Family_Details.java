package com.lti.WE.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="family_details")
public class Family_Details {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="fid")
	@SequenceGenerator(name="fid",sequenceName="f_no",allocationSize=1)
    private int fid;	
	private String father_name;
	private String father_occupation;
	private String mother_name;
	private String mother_occupation;
	private String spouse_name;
	private String spouse_occupation;
	 
	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getFather_occupation() {
		return father_occupation;
	}
	public void setFather_occupation(String father_occupation) {
		this.father_occupation = father_occupation;
	}
	public String getMother_name() {
		return mother_name;
	}
	public void setMother_name(String mother_name) {
		this.mother_name = mother_name;
	}
	public String getMother_occupation() {
		return mother_occupation;
	}
	public void setMother_occupation(String mother_occupation) {
		this.mother_occupation = mother_occupation;
	}
	public String getSpouse_name() {
		return spouse_name;
	}
	public void setSpouse_name(String spouse_name) {
		this.spouse_name = spouse_name;
	}
	public String getSpouse_occupation() {
		return spouse_occupation;
	}
	public void setSpouse_occupation(String spouse_occupation) {
		this.spouse_occupation = spouse_occupation;
	}
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	
	@Override
	public String toString() {
		return "Family_Details [fid=" + fid + ", father_name=" + father_name + ", father_occupation="
				+ father_occupation + ", mother_name=" + mother_name + ", mother_occupation=" + mother_occupation
				+ ", spouse_name=" + spouse_name + ", spouse_occupation=" + spouse_occupation + 
				"]";
	}
	

}
