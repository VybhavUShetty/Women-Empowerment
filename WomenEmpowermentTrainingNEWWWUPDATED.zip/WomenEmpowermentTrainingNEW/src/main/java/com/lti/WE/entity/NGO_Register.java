package com.lti.WE.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="ngo_details1")
public class NGO_Register {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="fid")
	@SequenceGenerator(name="fid",sequenceName="f_no",allocationSize=1)
	private int ngo_id;
	private String ngo_name;
	private String ngo_type;
	private String project_incharge;
	private String address;
	private String city;
	private String state;
	private String website;
	private String email;
	private String phone_no;
	public int getNgo_id() {
		return ngo_id;
	}
	public void setNgo_id(int ngo_id) {
		this.ngo_id = ngo_id;
	}
	public String getNgo_name() {
		return ngo_name;
	}
	public void setNgo_name(String ngo_name) {
		this.ngo_name = ngo_name;
	}
	public String getNgo_type() {
		return ngo_type;
	}
	public void setNgo_type(String ngo_type) {
		this.ngo_type = ngo_type;
	}
	public String getProject_incharge() {
		return project_incharge;
	}
	public void setProject_incharge(String project_incharge) {
		this.project_incharge = project_incharge;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	@Override
	public String toString() {
		return "NGO_Register [ngo_id=" + ngo_id + ", ngo_name=" + ngo_name + ", ngo_type=" + ngo_type
				+ ", project_incharge=" + project_incharge + ", address=" + address + ", city=" + city + ", state="
				+ state + ", website=" + website + ", email=" + email + ", phone_no=" + phone_no + "]";
	}
	
	

}
