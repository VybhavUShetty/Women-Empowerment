package com.lti.WE.entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="personal_details")
public class Personal_Details {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="reg_id")
	@SequenceGenerator(name="reg_id",sequenceName="reg_no",allocationSize=1)
	private int reg_id;
	private String first_name;
//	user_id(foreign key references)
	private String last_name;
	private String nationality;
	private String aadhar_no;
	private String caste;
	private String marital_status;
	//private String user_satus;
	private String physically_challenged;
	private String education;
	private String occupation;
	private int salary;
	public int getReg_id() {
		return reg_id;
	}
	public void setReg_id(int reg_id) {
		this.reg_id = reg_id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getAadhar_no() {
		return aadhar_no;
	}
	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}
	public String getCaste() {
		return caste;
	}
	public void setCaste(String caste) {
		this.caste = caste;
	}
	public String getMarital_status() {
		return marital_status;
	}
	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}
	public String getPhysically_challenged() {
		return physically_challenged;
	}
	public void setPhysically_challenged(String physically_challenged) {
		this.physically_challenged = physically_challenged;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return "Personal_Details [reg_id=" + reg_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", nationality=" + nationality + ", aadhar_no=" + aadhar_no + ", caste=" + caste + ", marital_status="
				+ marital_status + ", physically_challenged=" + physically_challenged + ", education=" + education
				+ ", occupation=" + occupation + ", salary=" + salary +  "]";
	}

	
	
	
}
