package com.lti.WE.entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="New_user")
public class Register {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="user_id")
	@SequenceGenerator(name="user_id",sequenceName="user_no",allocationSize=1)
	private int user_id;
	private String name;
	private String user_name;
	private String  dob;
	private String password;
	private String confirm_password;
	private int phone_no;
	public int getUser_id() {
		return user_id;
	}
	public Register() {}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirm_password() {
		return confirm_password;
	}
	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}
	public int getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(int phone_no) {
		this.phone_no = phone_no;
	}
	@Override
	public String toString() {
		return "Register [user_id=" + user_id + ", name=" + name + ", user_name=" + user_name + ", dob=" + dob
				+ ", password=" + password + ", confirm_password=" + confirm_password + ", phone_no=" + phone_no + "]";
	}

}
