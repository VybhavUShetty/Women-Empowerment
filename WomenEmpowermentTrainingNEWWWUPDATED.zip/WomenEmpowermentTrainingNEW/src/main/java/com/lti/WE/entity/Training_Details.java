package com.lti.WE.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="training_details")
public class Training_Details {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="tid")
	@SequenceGenerator(name="tid",sequenceName="t_no",allocationSize=1)
	private int tid;
	private String training_name;
	private String training_duration;
	private String training_location;
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTraining_name() {
		return training_name;
	}
	public void setTraining_name(String training_name) {
		this.training_name = training_name;
	}
	public String getTraining_duration() {
		return training_duration;
	}
	public void setDuration(String training_duration) {
		this.training_duration = training_duration;
	}
	public String getTraining_location() {
		return training_location;
	}
	public void setTraining_location(String training_location) {
		this.training_location = training_location;
	}
	@Override
	public String toString() {
		return "Training_Details [tid=" + tid + ", training_name=" + training_name + ", training_duration=" + training_duration
				+ ", training_location=" + training_location + "]";
	}
	
	
}