package com.lti.WE.service;

import com.lti.WE.entity.Contact_Details;


public interface Contact_DetailsService {
	public boolean saveUser(Contact_Details cdetails);
}
