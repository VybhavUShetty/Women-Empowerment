package com.lti.WE.service;

import com.lti.WE.entity.Family_Details;

public interface Family_DetailsService {
	public boolean saveUser(Family_Details fdetails);
}
