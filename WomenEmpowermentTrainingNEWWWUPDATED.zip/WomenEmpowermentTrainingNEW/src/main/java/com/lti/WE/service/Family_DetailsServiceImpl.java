package com.lti.WE.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.WE.dao.Family_DetailsDao;
import com.lti.WE.entity.Family_Details;

@Service
@Transactional
public class Family_DetailsServiceImpl implements Family_DetailsService {

		// Implementing Constructor based DI
	private Family_DetailsDao frepository;

	
	public Family_DetailsServiceImpl() {
		
	}
	
	@Autowired
	public Family_DetailsServiceImpl(Family_DetailsDao frepository) {
		super();
		this.frepository = frepository;
	}
	
	/*@Override
	public List<Author> getAllUsers() {
		List<Author> list = new ArrayList<Author>();
		repository.findAll().forEach(e -> list.add(e));
		return list;
	}

	@Override
	public Author getUserById(Long id) {
		Author user = repository.findById(id).get();
		return user;
	}
	public boolean saveUser(Family_Details fregister) {
		try {
			frepository.save(fregister);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	/*@Override
	public boolean deleteUserById(Long id) {
		try {
			repository.deleteById(id);
			return true;
		}catch(Exception ex) {
			return false;
		}
		
	}*/
	public boolean saveUser(Family_Details fregister) {
	Boolean as=frepository.saveUser(fregister);
	return as;
	}
	}



