package com.lti.WE.service;

import com.lti.WE.entity.Register;

public interface LoginService {
	
	public Register isValidUser(String user_name, String password);
}


