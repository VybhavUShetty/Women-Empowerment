package com.lti.WE.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.WE.dao.LoginDao;
import com.lti.WE.entity.Register;
@Service
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	private LoginDao loginDao;
	 
 
   
	@Override
	public Register isValidUser(String user_name, String password) {
		return loginDao.isValidUser1(user_name, password);
	}


}
