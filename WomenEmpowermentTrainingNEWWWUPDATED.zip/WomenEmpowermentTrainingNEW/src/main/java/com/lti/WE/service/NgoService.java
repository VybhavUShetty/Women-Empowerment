package com.lti.WE.service;

import com.lti.WE.entity.NGO_Register;
import com.lti.WE.entity.Register;

public interface NgoService {
	public boolean saveNgoUser(NGO_Register ngoregister);
}
