
package com.lti.WE.service;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.WE.dao.NgoDao;
import com.lti.WE.entity.NGO_Register;
@Service
@Transactional
public class NgoServiceImpl implements NgoService {
	// Implementing Constructor based DI
	private NgoDao nrepository;
	
	public NgoServiceImpl() {
		
	}
	
	@Autowired
	public NgoServiceImpl(NgoDao nrepository) {
		super();
		this.nrepository = nrepository;
	}
	
/*@Override
public List<Author> getAllUsers() {
	List<Author> list = new ArrayList<Author>();
	repository.findAll().forEach(e -> list.add(e));
	return list;
}

@Override
public Author getUserById(Long id) {
	Author user = repository.findById(id).get();
	return user;
}

public boolean saveNgoUser(NGO_Register ngoregister) {
	try {
		nrepository.save(ngoregister);
		return true;
	}catch(Exception ex) {
		return false;
	}
}

/*@Override
public boolean deleteUserById(Long id) {
	try {
		repository.deleteById(id);
		return true;
	}catch(Exception ex) {
		return false;
	}
	
}*/
	public boolean saveNgoUser(NGO_Register ngoregister) {
		Boolean as=nrepository.saveUser(ngoregister);
		return as;
	}

}

