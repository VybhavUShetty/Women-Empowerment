package com.lti.WE.service;

import java.util.List;

import com.lti.WE.entity.Personal_Details;

public interface Personal_DetailsService {

	public List<Personal_Details> getAllUsers();
	public Personal_Details getUserById(int reg_id);
	public boolean saveUser(Personal_Details pdetails);
	public boolean deleteUserById(int reg_id);

	
}