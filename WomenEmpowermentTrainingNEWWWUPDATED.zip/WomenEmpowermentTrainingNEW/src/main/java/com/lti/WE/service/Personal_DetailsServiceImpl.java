package com.lti.WE.service;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.WE.dao.Personal_DetailsDao;
import com.lti.WE.entity.Personal_Details;
@Service
@Transactional
public class Personal_DetailsServiceImpl implements Personal_DetailsService {
	// Implementing Constructor based DI
	private Personal_DetailsDao prepository;
	
	public Personal_DetailsServiceImpl() {
		
	}
	
	@Autowired
	public Personal_DetailsServiceImpl(Personal_DetailsDao prepository) {
		super();
		this.prepository = prepository;
	}
	


public List<Personal_Details> getAllUsers() {
	List<Personal_Details> userList = new ArrayList<Personal_Details>();
	prepository.getAllUsers();
	return userList;
}


@Override
public Personal_Details getUserById(int reg_id) {
	Personal_Details user = prepository. getUserById(reg_id);
	return user;
}


public boolean saveUser(Personal_Details pregister) {
	try {
		prepository.saveUser(pregister);
		return true;
	}catch(Exception ex) {
		return false;
	}
}


public boolean deleteUserById(int reg_id) {
	try {
		prepository.deleteUserById(reg_id);
		return true;
	}catch(Exception ex) {
		return false;
	}
	
}

}
