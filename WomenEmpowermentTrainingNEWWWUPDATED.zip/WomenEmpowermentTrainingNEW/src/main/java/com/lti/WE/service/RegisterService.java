package com.lti.WE.service;

import com.lti.WE.entity.Register;

public interface RegisterService {

	/*public List<Register> getAllUsers();
	public Register getUserById(Long id);*/
	public boolean saveUser(Register register);
//	public boolean deleteUserById(Long id);

}