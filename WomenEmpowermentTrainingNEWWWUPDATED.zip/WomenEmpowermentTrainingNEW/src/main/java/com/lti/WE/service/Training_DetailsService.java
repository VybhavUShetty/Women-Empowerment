package com.lti.WE.service;

import com.lti.WE.entity.Training_Details;

public interface Training_DetailsService {
	public boolean saveUser(Training_Details tdetails);
}
