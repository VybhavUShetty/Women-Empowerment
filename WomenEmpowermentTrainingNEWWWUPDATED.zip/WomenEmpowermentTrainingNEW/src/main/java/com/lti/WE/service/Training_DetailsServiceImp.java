
package com.lti.WE.service;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.WE.dao.Training_DetailsDao;
import com.lti.WE.entity.Training_Details;
@Service
@Transactional
public class Training_DetailsServiceImp implements Training_DetailsService {
	// Implementing Constructor based DI
	private Training_DetailsDao trepository;
	
	public Training_DetailsServiceImp() {
		
	}
	
	@Autowired
	public Training_DetailsServiceImp(Training_DetailsDao trepository) {
		super();
		this.trepository = trepository;
	}
	
/*@Override
public List<Author> getAllUsers() {
	List<Author> list = new ArrayList<Author>();
	repository.findAll().forEach(e -> list.add(e));
	return list;
}

@Override
public Author getUserById(Long id) {
	Author user = repository.findById(id).get();
	return user;
}
public boolean saveUser(Training_Details tdetails) {
	try {
		trepository.save(tdetails);
		return true;
	}catch(Exception ex) {
		return false;
	}
}

/*@Override
public boolean deleteUserById(Long id) {
	try {
		repository.deleteById(id);
		return true;
	}catch(Exception ex) {
		return false;
	}
	
}*/
	public boolean saveUser(Training_Details tdetails) {
		Boolean as=trepository.saveUser(tdetails);
		return as;
	}
	

}
